(= c (int \;)) (do (.readLine s) :line-start)
