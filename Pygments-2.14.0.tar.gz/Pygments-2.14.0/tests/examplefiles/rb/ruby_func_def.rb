class (get_foo("blub"))::Foo
  def (foo("bar") + bar("baz")).something argh, aaahaa
    42
  end
end

class get_the_fuck("out")::Of::My
  def parser_definition
    ruby!
  end
end
