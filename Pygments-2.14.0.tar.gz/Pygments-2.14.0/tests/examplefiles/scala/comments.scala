// Comments
/* Comment block */
/* Multi-line 
 * comment block
 */
/*  /**/ /** */ /* comments within comments */ */
/**   /* */ /** **/ **/
// /* Commented-out comment block
// Line comment