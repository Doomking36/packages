true false null
1 2 3 4
1L 1l 10L 12123123L
3.0 12.345
3f 3.0f 3F 3.0F
3d 3.0d 3D 3.0D
110_222_795_799.99 110.9499_999 2_000.343_999e561_100
1e12 1e+34 1e-56 1e12f 1e+34f 1e-56f 1e12d 1e+34d 1e-56d
1E12 1E+34 1E-56 1E12f 1E+34f 1E-56f 1E12d 1E+34d 1E-56d
.1e12 .1e+34 .1e-56 .1e12f .1e+34f .1e-56f .1e12d .1e+34d .1e-56d
.1E12 .1E+34 .1E-56 .1E12f .1E+34f .1E-56f .1E12d .1E+34d .1E-56d
0x // Can still be highlighted correctly!
0x1234567890ABCDEF 0x1234567890abcdef
0x123_abc 0x123_ABC
"test" "\"test\"" "'test'" // comment
"""test: one ", two "", three """""" // comment
't' '"' '\'' '\n' ' '
super this