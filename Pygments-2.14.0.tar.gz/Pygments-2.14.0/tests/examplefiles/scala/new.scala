new A
new { }
new Foo
new foo.Foo
new Foo.Foo
new A:
  def f = 3