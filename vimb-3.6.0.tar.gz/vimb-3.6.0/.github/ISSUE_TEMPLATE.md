<!-- If this is a bug report, please provide your version information
$ vimb --bug-info -->
### Steps to reproduce

### Expected behaviour

### Actual behaviour
