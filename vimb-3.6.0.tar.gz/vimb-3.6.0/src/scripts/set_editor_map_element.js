if (typeof(vimb_editor_map) !== 'object') {
    var vimb_editor_map = new Map;
}
vimb_editor_map.set("%lu", vimb_input_mode_element);
