vimb_editor_map.get("%lu").disabled=false;
vimb_editor_map.get("%lu").focus();
